#!/bin/bash          
            STR="Hello World!"
            echo $STR 
